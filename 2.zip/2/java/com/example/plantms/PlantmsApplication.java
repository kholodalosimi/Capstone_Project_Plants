package com.example.plantms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlantmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlantmsApplication.class, args);
	}

}
