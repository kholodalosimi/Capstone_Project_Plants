import React, { useEffect, useState } from 'react'
import axios from "axios"
export default function App() {
  const [myUsers, setMyUsers] = useState({id:"",name:"",phone:"",email:"",numberOfPlants:"",picture:"",username:"",password:""})



  //Users
 useEffect(()=>{
   axios.get("/api/users")
    .then(response=>{
      console.log(response.data)
      setMyUsers(response.data[1])
   })
   return()=>{}
 },[])



// Users add
function handleClick(){
  axios({
    method:'post',
    url:'api/users/add',
    data:{
      id:3,
      name:"ge",
      phone:56768,
      email:"gg@gg.com",
      numberOfPlants:324,
      picture:"ghj.png",
      username:"llliii",
      password:345435,

    }
  });
}


// Users delete 
function handleClickDel(){
  axios({
    method:'delete',
    url:"/api/Users/delete/"
  })}

  
  return (
    <div>
            <br></br>
      <br></br>
      <h2> details are:  </h2>
      <button onClick={handleClick}>Post to Spring </button>
      <button onClick={handleClickDel}>Delet to Spring </button>

    </div>
  )
}